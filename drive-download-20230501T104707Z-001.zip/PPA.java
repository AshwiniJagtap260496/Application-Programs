package Marvellous.Batches;

public class PPA
{
    public void Display()
    {
        System.out.println("It is foundation batch");
    }
}