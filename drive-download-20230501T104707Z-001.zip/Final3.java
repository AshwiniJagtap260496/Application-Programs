final class Base
{
    // code
}

class Derived extends Base
{
    // code
}

class Final3
{
    public static void main(String Arg[])
    {
        Base bobj = new Base();
    }
}
