int Y = 20;

double d = 90.99;