
class Marvellous    // class Marvellous extends Object
{

}

class GetClassDemo  // class GetClassDemo extends Object
{
    public static void main(String A[])
    {
        Marvellous mobj = new Marvellous();
        System.out.println("Name of the class is : "+mobj.getClass());
    }
}




void fun(Object ref)
{
    
}

Demo obj = new Demo();

fun(obj);