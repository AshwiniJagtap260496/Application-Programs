#include<iostream>
using namespace std;

const int A = 10;

int main()
{
    const int B = 20;
    const int Arr[4] = {10,20,30,40};

 //   const int No;
 //   No = 11;

    const int No = 11;
/*
    A = 11;
    A++;
    A--;
    B = 21;
    B++;
    B--;
    Arr[1] = 21;
    Arr[2]++;
*/
    return 0;
}