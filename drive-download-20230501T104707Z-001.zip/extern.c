
int B = 20;

int C;
