#include<stdio.h>

int main()
{
    int No = 11;

    int *p = &No;

    int *q = &No;

    return 0;
}