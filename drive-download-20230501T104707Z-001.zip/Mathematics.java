package Marvellous;

public class Mathematics
{
    public int Square(int A)
    {
        return A*A;
    }
    public int Cube(int A)
    {
        return A*A*A;
    }
}

// javac -d . Mathematics.java

// javac                Name of java compiler
// -d                   Create Directory (Folder)
// .                    Current directory (Jithe .java file ahe tyach folder madhe)
// Mathematics.java     Name of java file